import sys
from PySide6.QtWidgets import (
    QApplication, QWidget, QVBoxLayout, QFormLayout, QLineEdit, QPushButton, QLabel, QMessageBox
)
from brayton_cycle import BraytonCycle

class BraytonCycleApp(QWidget):
    def __init__(self):
        super().__init__()
        self.initUI()
    
    def initUI(self):
        self.setWindowTitle('Brayton Cycle Analysis')
        
        self.layout = QVBoxLayout()

        self.formLayout = QFormLayout()

        self.T1_input = QLineEdit()
        self.P1_input = QLineEdit()
        self.pressure_ratio_input = QLineEdit()
        self.T3_input = QLineEdit()
        self.Cp_input = QLineEdit()
        self.Cv_input = QLineEdit()

        self.formLayout.addRow('Ambient Temperature (T1 in K):', self.T1_input)
        self.formLayout.addRow('Ambient Pressure (P1 in Pa):', self.P1_input)
        self.formLayout.addRow('Pressure Ratio (P2/P1):', self.pressure_ratio_input)
        self.formLayout.addRow('Temperature after Heat Addition (T3 in K):', self.T3_input)
        self.formLayout.addRow('Specific Heat at Constant Pressure (Cp in J/kg.K):', self.Cp_input)
        self.formLayout.addRow('Specific Heat at Constant Volume (Cv in J/kg.K):', self.Cv_input)

        self.calculateButton = QPushButton('Calculate and Plot')
        self.calculateButton.clicked.connect(self.onCalculate)

        self.layout.addLayout(self.formLayout)
        self.layout.addWidget(self.calculateButton)
        
        self.setLayout(self.layout)
    
    def onCalculate(self):
        try:
            T1 = float(self.T1_input.text())
            P1 = float(self.P1_input.text())
            pressure_ratio = float(self.pressure_ratio_input.text())
            T3 = float(self.T3_input.text())
            Cp = float(self.Cp_input.text())
            Cv = float(self.Cv_input.text())

            cycle = BraytonCycle(T1, P1, pressure_ratio, T3, Cp, Cv)
            cycle.plot_TS_diagram()
            cycle.plot_PV_diagram()
            cycle.plot_enthalpy_diagram()
        
        except ValueError:
            QMessageBox.critical(self, "Input Error", "Please enter valid numerical values.")

def main():
    app = QApplication(sys.argv)
    ex = BraytonCycleApp()
    ex.show()
    sys.exit(app.exec())

if __name__ == "__main__":
    main()
