import numpy as np
import matplotlib.pyplot as plt
from dataclasses import dataclass, field
from typing import List, Tuple

@dataclass
class BraytonCycle:
    T1: float
    P1: float
    pressure_ratio: float
    T3: float
    Cp: float
    Cv: float
    R: float = field(init=False)
    gamma: float = field(init=False)
    T2: float = field(init=False, default=0.0)
    T4: float = field(init=False, default=0.0)
    P2: float = field(init=False, default=0.0)
    P3: float = field(init=False, default=0.0)
    P4: float = field(init=False, default=0.0)
    states: List[Tuple[float, float]] = field(init=False, default_factory=list)

    def __post_init__(self):
        self.R = self.Cp - self.Cv
        self.gamma = self.Cp / self.Cv
        self.calculate_states()
    
    def calculate_states(self):
        self.P2 = self.P1 * self.pressure_ratio
        self.T2 = self.T1 * (self.pressure_ratio)**((self.gamma - 1)/self.gamma)
        
        self.P3 = self.P2
        self.P4 = self.P1
        self.T4 = self.T3 * (self.P4/self.P3)**((self.gamma - 1)/self.gamma)
        
        self.states = [(self.T1, self.P1), (self.T2, self.P2), (self.T3, self.P3), (self.T4, self.P4)]
    
    def plot_TS_diagram(self):
        entropy_changes = [
            0,
            self.Cp * np.log(self.T2/self.T1),
            self.Cp * np.log(self.T3/self.T2),
            self.Cp * np.log(self.T4/self.T3)
        ]
        entropies = np.cumsum(entropy_changes)
        temperatures = [state[0] for state in self.states]

        plt.figure()
        plt.plot(entropies, temperatures, marker='o')
        plt.title('T-S Diagram')
        plt.xlabel('Entropy (J/K)')
        plt.ylabel('Temperature (K)')
        plt.grid()
        plt.show()

    def plot_PV_diagram(self):
        volumes = [self.R * T / P for T, P in self.states]
        pressures = [state[1] for state in self.states]

        plt.figure()
        plt.plot(volumes, pressures, marker='o')
        plt.title('P-V Diagram')
        plt.xlabel('Volume (m³)')
        plt.ylabel('Pressure (Pa)')
        plt.grid()
        plt.show()

    def plot_enthalpy_diagram(self):
        enthalpies = [self.Cp * state[0] for state in self.states]
        temperatures = [state[0] for state in self.states]

        plt.figure()
        plt.plot(temperatures, enthalpies, marker='o')
        plt.title('Enthalpy Diagram')
        plt.xlabel('Temperature (K)')
        plt.ylabel('Enthalpy (J)')
        plt.grid()
        plt.show()
