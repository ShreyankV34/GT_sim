# Brayton Cycle Analysis Project

This project provides a GUI to analyze the Brayton Cycle for gas turbines. Users can input ambient conditions, specific heats, and other parameters to calculate and visualize the cycle.

## Installation

1. Clone the repository.
2. Install the required packages using:

    ```
    pip install -r requirements.txt
    ```

## Usage

Run the `main.py` file to start the application:

```
python main.py
```

## Features

- Input fields for ambient conditions and specific heats.
- Calculation of Brayton Cycle parameters.
- Plotting of T-S, P-V, and enthalpy diagrams.
